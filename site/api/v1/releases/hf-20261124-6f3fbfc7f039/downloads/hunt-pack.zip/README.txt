HuntForge KQL pack. Run each .kql file as a separate query in its documented target.
